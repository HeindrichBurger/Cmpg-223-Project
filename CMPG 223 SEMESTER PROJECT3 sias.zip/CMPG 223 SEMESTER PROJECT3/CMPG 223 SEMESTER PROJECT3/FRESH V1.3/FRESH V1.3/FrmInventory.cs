﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace FRESH_V1._3
{
    public partial class FrmInventory : Form
    {
        //Declare variables
        SqlConnection conn;
        SqlCommand comm;
        SqlDataAdapter dataAdapter;
        SqlDataReader dataReader;
        DataSet ds;
        string connetionString;

        public FrmInventory()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {


            int farmerID = int.Parse(txtFarmID.Text);
            int ProductID = int.Parse(txtProdID.Text);
            int purchaseid = int.Parse(txtPurchaseID.Text);
            int purchasequantity = int.Parse(txtAmountpurchesed.Text);
            int totQuantity = int.Parse(txtTotAmount.Text);
            double cost = double.Parse(txtPurchaseCost.Text);
            double price = double.Parse(txtUnitPrice.Text);
            string description = txtProductdiscription.Text;

            connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Esias\Downloads\CMPG 223 SEMESTER PROJECT3\CMPG 223 SEMESTER PROJECT3\FRESH V1.3\FRESH V1.3\Database1.mdf"";Integrated Security=True";
            conn = new SqlConnection(connetionString);

            conn.Open();

          
            

            

            //Initialize variables and select all data from Venue table
            string sql = "INSERT INTO INVENTORY VALUES(" + purchaseid + "," + ProductID + "," + farmerID + "," + purchasequantity + "," + totQuantity + "," + cost + ","+monthCalendar1.TodayDate+"  ," + price + ",'" + description + "')";
            comm = new SqlCommand(sql, conn);
            comm.ExecuteNonQuery();           
            conn.Close();

            conn.Open();
            comm= new SqlCommand("SELECT * FROM INVENTORY ", conn);
            dataAdapter = new SqlDataAdapter();
            ds = new DataSet();

            //Fill the dataset
            dataAdapter.SelectCommand = comm;
            dataAdapter.Fill(ds, "INVENTORY");

            //Move data to datagrid
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "INVENTORY";

            //Close the connection
            conn.Close();

        }

        private void FrmInventory_Load(object sender, EventArgs e)
        {

            connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Esias\Downloads\CMPG 223 SEMESTER PROJECT3\CMPG 223 SEMESTER PROJECT3\FRESH V1.3\FRESH V1.3\Database1.mdf"";Integrated Security=True";
            conn = new SqlConnection(connetionString);

            conn.Open();

            //Declare variables
            dataAdapter = new SqlDataAdapter();
            ds = new DataSet();

            //Initialize variables and select all data from Venue table
            string sql = "SELECT * FROM INVENTORY";
            comm = new SqlCommand(sql, conn);

            //Fill the dataset
            dataAdapter.SelectCommand = comm;
            dataAdapter.Fill(ds, "INVENTORY");

            //Move data to datagrid
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "INVENTORY";

            //Close the connection
            conn.Close();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int farmerID = int.Parse(txtFarmID.Text);
            int ProductID = int.Parse(txtProdID.Text);
            int purchaseid = int.Parse(txtPurchaseID.Text);
            int purchasequantity = int.Parse(txtAmountpurchesed.Text);
            int totQuantity = int.Parse(txtTotAmount.Text);
            double cost = double.Parse(txtPurchaseCost.Text);
            double price = double.Parse(txtUnitPrice.Text);
            string description = txtProductdiscription.Text;

            connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Esias\Downloads\CMPG 223 SEMESTER PROJECT3\CMPG 223 SEMESTER PROJECT3\FRESH V1.3\FRESH V1.3\Database1.mdf"";Integrated Security=True";
            conn = new SqlConnection(connetionString);

            conn.Open();

            //Declare variables


            

            //Initialize variables and select all data from Venue table
            string sql = "INSERT INTO INVENTORY VALUES (" + purchaseid + "," + ProductID + "," + farmerID + "," + purchasequantity + "," + totQuantity + "," + cost + ", "+monthCalendar1.TodayDate+" ," + price + ",'" + description + "') WHERE PurchaseID = "+purchaseid+"";
            comm = new SqlCommand(sql, conn);
            comm.ExecuteNonQuery();
            conn.Close();

            conn.Open();
            comm = new SqlCommand("SELECT * FROM INVENTORY ", conn);
            dataAdapter = new SqlDataAdapter();
            ds = new DataSet();

            //Fill the dataset
            dataAdapter.SelectCommand = comm;
            dataAdapter.Fill(ds, "INVENTORY");

            //Move data to datagrid
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "INVENTORY";

            //Close the connection
            conn.Close();
        }
    }
}
