﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FRESH_V1._3
{
    public partial class frmReport : Form
    {
        //Declare variables
        SqlConnection conn;
        SqlCommand comm;
        SqlDataAdapter dataAdapter;
        SqlDataReader dataReader;
        DataSet ds;
        string connetionString;

        public frmReport()
        {
            InitializeComponent();
        }

        private void frmReport_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                checkBox2.Checked = false;
                checkBox3.Checked = false;
            }

            //Establish connection
            connetionString = @"Data Source=DESKTOP-9TT728P;Initial Catalog=FRESH;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False";
            conn = new SqlConnection(connetionString);
          





            //Open the connection
            conn.Open();

            //Declare variables
            dataAdapter = new SqlDataAdapter();
            ds = new DataSet();

            //Initialize variables and select all data from Venue table
            string sql = "SELECT * FROM INVENTORY_FROM_SALES";
            comm = new SqlCommand(sql, conn);

            //Fill the dataset
            dataAdapter.SelectCommand = comm;
            dataAdapter.Fill(ds, "INVENTORY_FROM_SALES");

            //Move data to datagrid
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "INVENTORY_FROM_SALES";

            //Close the connection
            conn.Close();


            //Change the report heading

            lbl_Rheading.Text = "Report on Delivery Logs:";

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                checkBox1.Checked = false;
                checkBox3.Checked = false;
            }
            //Open the connection
            connetionString = @"Data Source=DESKTOP-9TT728P;Initial Catalog=FRESH;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False";
            conn.Open();

            //Declare variables
            dataAdapter = new SqlDataAdapter();
            ds = new DataSet();

            //Initialize variables and select all data from Venue table
            string sql = "SELECT * FROM SALES_ORDER";
            comm = new SqlCommand(sql, conn);

            //Fill the dataset
            dataAdapter.SelectCommand = comm;
            dataAdapter.Fill(ds, "SALES_ORDER");

            //Move data to datagrid
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "SALES_ORDER";

            //Close the connection
            conn.Close();

            //Change the report heading

            lbl_Rheading.Text = "Report on Sales Logs:";
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                checkBox2.Checked = false;
                checkBox1.Checked = false;
            }

            //Open the connection
            connetionString = @"Data Source=DESKTOP-9TT728P;Initial Catalog=FRESH;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False";
            conn.Open();

            //Declare variables
            dataAdapter = new SqlDataAdapter();
            ds = new DataSet();

            //Initialize variables and select all data from Venue table
            string sql = "SELECT * FROM INVENTORY_FROM_FARM";
            comm = new SqlCommand(sql, conn);

            //Fill the dataset
            dataAdapter.SelectCommand = comm;
            dataAdapter.Fill(ds, "INVENTORY_FROM_FARM");

            //Move data to datagrid
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "INVENTORY_FROM_FARM";

            //Close the connection
            conn.Close();

            //Change the report heading

            lbl_Rheading.Text = "Report on Purchase Log:";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
